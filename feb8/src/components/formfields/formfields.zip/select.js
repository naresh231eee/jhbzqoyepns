import React from "react";
var SelectOption = React.createClass({
   getInitialState() {
      return {
         "value": null,
      }
   },
    render() {

    return (
            <option value={this.props.value}>{this.props.view}</option>
        )
    },
   defaultOnChange(){

   }

});

var SelectBox = React.createClass({
    
    render() {
       // console.log(this.props.data);
       var placeholderoption = null;
       if(this.props.placeholder){
          placeholderoption = <SelectOption value="" key='999' view={this.props.placeholder} className="form-control" />;
       }

        return (
            <div>
                <select id={this.props.sid ? this.props.sid : ''}
                        className="boxMinWidth"
                        value={this.props.selected}
                        onChange={this.props.onChange} placeholder={this.props.placeholder ? this.props.placeholder : ''}>

                   {placeholderoption};
                 {this.props.data && (this.props.data).map((result, index) => (
                    <SelectOption key={index+'d'} value={result[this.props.id]} view={result[this.props.value]} className="form-control" />
                 ))}
                </select>
            </div>
        );
    }
});

export default SelectBox;