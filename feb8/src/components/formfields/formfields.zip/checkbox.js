import React from "react";

var CheckBox = React.createClass({
   getInitialState() {
      return {
         "checked": false,
      }
   },
   
    render() {
        return (
           <input onclick={this.props.onChange} id={this.props.sid ? this.props.sid : ''}
               checked={this.props.checked} className={this.props.classBankRow} value={this.props.rowIndex} type="checkbox">
          </input>

        );
    }
});

export default CheckBox;